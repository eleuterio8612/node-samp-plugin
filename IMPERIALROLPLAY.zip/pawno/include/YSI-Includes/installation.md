Use sampctl!

```
sampctl package install pawn-lang/YSI-Includes@5.x
```

